import React, { useState } from 'react';
import { Search, TrendingUp, Users, Play, Clock, Star, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Screen } from '../App';

interface TrendingScreenProps {
  onNavigate: (screen: Screen, data?: any) => void;
}

interface PlaylistData {
  id: string;
  title: string;
  thumbnail: string;
  totalVideos: number;
  totalDuration: string;
  category: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  rating: number;
  enrollments: number;
  badges: string[];
}

export function TrendingScreen({ onNavigate }: TrendingScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  const mockTrendingPlaylists: PlaylistData[] = [
    {
      id: '1',
      title: 'Complete SQL Mastery for Data Analysis',
      thumbnail: 'https://images.unsplash.com/photo-1694878982098-1cec80d96eca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2RpbmclMjB0dXRvcmlhbCUyMHZpZGVvJTIwdGh1bWJuYWlsfGVufDF8fHx8MTc1NzQzMTY1NHww&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 24,
      totalDuration: '8h 45m',
      category: 'Data Science',
      difficulty: 'Beginner',
      rating: 4.8,
      enrollments: 15240,
      badges: ['AI Pick', 'Trending Now']
    },
    {
      id: '2',
      title: 'Excel Power User: Advanced Formulas & Analytics',
      thumbnail: 'https://images.unsplash.com/photo-1606327054581-899eb5e6d1dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNlbCUyMHNwcmVhZHNoZWV0JTIwdHV0b3JpYWx8ZW58MXx8fHwxNzU3NDMxNjU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 18,
      totalDuration: '6h 20m',
      category: 'Business Skills',
      difficulty: 'Intermediate',
      rating: 4.9,
      enrollments: 12800,
      badges: ['Hot Topic']
    },
    {
      id: '3',
      title: 'AI Tools Mastery: ChatGPT, Claude & More',
      thumbnail: 'https://images.unsplash.com/photo-1564707944519-7a116ef3841c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGFydGlmaWNpYWwlMjBpbnRlbGxpZ2VuY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1NzM4NjUzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 16,
      totalDuration: '5h 15m',
      category: 'AI & Technology',
      difficulty: 'Beginner',
      rating: 4.7,
      enrollments: 18900,
      badges: ['AI Pick', 'Most Popular']
    },
    {
      id: '4',
      title: 'Digital Marketing Strategy 2024',
      thumbnail: 'https://images.unsplash.com/photo-1709715357564-ab64e091ead9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBzdHJhdGVneSUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NTc0MzE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 22,
      totalDuration: '7h 30m',
      category: 'Marketing',
      difficulty: 'Intermediate',
      rating: 4.6,
      enrollments: 9450,
      badges: ['Career-Focused']
    },
    {
      id: '5',
      title: 'Python Programming: Zero to Hero',
      thumbnail: 'https://images.unsplash.com/photo-1694878982098-1cec80d96eca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2RpbmclMjB0dXRvcmlhbCUyMHZpZGVvJTIwdGh1bWJuYWlsfGVufDF8fHx8MTc1NzQzMTY1NHww&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 35,
      totalDuration: '12h 15m',
      category: 'Programming',
      difficulty: 'Beginner',
      rating: 4.9,
      enrollments: 21300,
      badges: ['Trending Now']
    },
    {
      id: '6',
      title: 'Advanced Data Analysis with Power BI',
      thumbnail: 'https://images.unsplash.com/photo-1606327054581-899eb5e6d1dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNlbCUyMHNwcmVhZHNoZWV0JTIwdHV0b3JpYWx8ZW58MXx8fHwxNzU3NDMxNjU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      totalVideos: 19,
      totalDuration: '9h 45m',
      category: 'Data Science',
      difficulty: 'Advanced',
      rating: 4.8,
      enrollments: 7200,
      badges: ['Expert Level']
    }
  ];

  const filteredPlaylists = mockTrendingPlaylists.filter(playlist => {
    const matchesSearch = searchQuery === '' || 
      playlist.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      playlist.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTab = activeTab === 'all' || 
      (activeTab === 'beginner' && playlist.difficulty === 'Beginner') ||
      (activeTab === 'intermediate' && playlist.difficulty === 'Intermediate') ||
      (activeTab === 'advanced' && playlist.difficulty === 'Advanced') ||
      (activeTab === 'ai-pick' && playlist.badges.includes('AI Pick'));
    
    return matchesSearch && matchesTab;
  });

  const getBadgeColor = (badge: string) => {
    switch(badge) {
      case 'AI Pick': return 'bg-[#4F46E5] text-white';
      case 'Trending Now': return 'bg-[#FF0000] text-white';
      case 'Hot Topic': return 'bg-orange-500 text-white';
      case 'Most Popular': return 'bg-purple-500 text-white';
      case 'Career-Focused': return 'bg-[#22C55E] text-white';
      case 'Expert Level': return 'bg-gray-700 text-white';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch(difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Advanced': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handlePlaylistClick = (playlist: PlaylistData) => {
    // Navigate to a mock path based on the playlist
    const mockPath = {
      id: playlist.id,
      title: playlist.title,
      totalLessons: playlist.totalVideos,
      modules: [
        {
          title: 'Getting Started',
          level: 'Beginner' as const,
          estimatedTime: '~2 hrs total',
          lessons: [
            {
              id: '1',
              title: `Introduction to ${playlist.category}`,
              duration: '15:30',
              thumbnail: playlist.thumbnail,
              channel: 'Expert Academy',
              progress: 0,
              whyChosen: 'Perfect starting point'
            }
          ]
        }
      ]
    };
    
    onNavigate('path', mockPath);
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-[#FF0000]/5 via-transparent to-[#4F46E5]/5 min-h-screen">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-[#FF0000]" />
          <h1 className="text-2xl text-[#212121]">Trending in Your Area</h1>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search trending playlists..."
            className="w-full p-4 pr-12 text-base rounded-lg border-2 border-gray-200 focus:border-[#4F46E5] focus:ring-2 focus:ring-[#4F46E5]/20"
          />
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>
      </div>

      {/* Simplified Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-white/80 backdrop-blur-sm rounded-xl p-1 border-2 border-[#4F46E5]/10">
          <TabsTrigger 
            value="all"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#4F46E5] data-[state=active]:to-[#3B82F6] data-[state=active]:text-white rounded-lg transition-all duration-200"
          >
            All
          </TabsTrigger>
          <TabsTrigger 
            value="beginner"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#22C55E] data-[state=active]:to-[#4F46E5] data-[state=active]:text-white rounded-lg transition-all duration-200"
          >
            Beginner
          </TabsTrigger>
          <TabsTrigger 
            value="intermediate"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#FACC15] data-[state=active]:to-[#4F46E5] data-[state=active]:text-white rounded-lg transition-all duration-200"
          >
            Intermediate
          </TabsTrigger>
          <TabsTrigger 
            value="advanced"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#EF4444] data-[state=active]:to-[#4F46E5] data-[state=active]:text-white rounded-lg transition-all duration-200"
          >
            Advanced
          </TabsTrigger>
          <TabsTrigger 
            value="ai-pick"
            className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-[#4F46E5] data-[state=active]:to-[#FF0000] data-[state=active]:text-white rounded-lg transition-all duration-200"
          >
            🤖 AI Pick
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {/* Trending Stats */}
          <Card className="border-2 border-[#FF0000] bg-[#FF0000]/5 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium text-[#212121] mb-1">🔥 What's Hot Today</h3>
                  <p className="text-sm text-gray-600">
                    {filteredPlaylists.length} trending playlists • Updated hourly
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl text-[#FF0000]">
                    {filteredPlaylists.reduce((sum, p) => sum + p.enrollments, 0).toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-600">Total Learners</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Playlists Grid */}
          <div className="grid gap-4">
            {filteredPlaylists.map((playlist) => (
              <Card 
                key={playlist.id}
                className="cursor-pointer hover:shadow-md transition-all duration-200 border-2 border-gray-200 hover:border-[#4F46E5] bg-white"
                onClick={() => handlePlaylistClick(playlist)}
              >
                <CardContent className="p-0">
                  <div className="flex gap-4 p-4">
                    {/* Thumbnail */}
                    <div className="relative flex-shrink-0">
                      <div className="w-32 h-20 bg-gray-200 rounded-lg overflow-hidden">
                        <ImageWithFallback
                          src={playlist.thumbnail}
                          alt={playlist.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                          <div className="w-10 h-10 bg-[#FF0000] rounded-full flex items-center justify-center">
                            <Play className="w-5 h-5 text-white ml-0.5" fill="white" />
                          </div>
                        </div>
                        <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                          {playlist.totalVideos} videos
                        </div>
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 space-y-2">
                      <h3 className="font-medium text-[#212121] line-clamp-2 leading-tight">
                        {playlist.title}
                      </h3>
                      
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Clock className="w-3 h-3" />
                        <span>{playlist.totalDuration}</span>
                        <span>•</span>
                        <Users className="w-3 h-3" />
                        <span>{playlist.enrollments.toLocaleString()}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-yellow-500" fill="currentColor" />
                          <span className="text-sm font-medium">{playlist.rating}</span>
                        </div>
                        <Badge className={getDifficultyColor(playlist.difficulty)}>
                          {playlist.difficulty}
                        </Badge>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {playlist.badges.map((badge, index) => (
                          <Badge key={index} className={`text-xs ${getBadgeColor(badge)}`}>
                            {badge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Empty State */}
          {filteredPlaylists.length === 0 && (
            <Card className="border-2 border-gray-200">
              <CardContent className="p-8 text-center">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="font-medium text-[#212121] mb-2">No playlists found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search or filter criteria
                </p>
                <Button 
                  onClick={() => {
                    setSearchQuery('');
                    setActiveTab('all');
                  }}
                  variant="outline"
                  className="border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white"
                >
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}