import React, { useState } from 'react';
import { Filter, Clock, Play, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { VideoCard } from './VideoCard';
import type { Screen, LessonData } from '../App';

interface MyPlaylistScreenProps {
  onNavigate: (screen: Screen, data?: any) => void;
}

export function MyPlaylistScreen({ onNavigate }: MyPlaylistScreenProps) {
  const [sortBy, setSortBy] = useState('recently-added');

  const mockPlaylistLessons: LessonData[] = [
    {
      id: '1',
      title: 'Getting Started with SQL Basics',
      duration: '12:45',
      thumbnail: 'https://images.unsplash.com/photo-1694878982098-1cec80d96eca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2RpbmclMjB0dXRvcmlhbCUyMHZpZGVvJTIwdGh1bWJuYWlsfGVufDF8fHx8MTc1NzQzMTY1NHww&ixlib=rb-4.1.0&q=80&w=1080',
      channel: 'DataBase Pro',
      progress: 75,
      whyChosen: 'Perfect for beginners'
    },
    {
      id: '2',
      title: 'Excel Advanced Formulas',
      duration: '18:30',
      thumbnail: 'https://images.unsplash.com/photo-1606327054581-899eb5e6d1dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNlbCUyMHNwcmVhZHNoZWV0JTIwdHV0b3JpYWx8ZW58MXx8fHwxNzU3NDMxNjU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
      channel: 'Office Skills Hub',
      progress: 100,
      whyChosen: 'High rating',
      isCompleted: true
    },
    {
      id: '3',
      title: 'AI Tools for Marketing',
      duration: '25:15',
      thumbnail: 'https://images.unsplash.com/photo-1564707944519-7a116ef3841c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGFydGlmaWNpYWwlMjBpbnRlbGxpZ2VuY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1NzM4NjUzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
      channel: 'Marketing AI',
      progress: 30,
      whyChosen: 'Trending topic'
    },
    {
      id: '4',
      title: 'Python Programming Fundamentals',
      duration: '22:10',
      thumbnail: 'https://images.unsplash.com/photo-1709715357564-ab64e091ead9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBzdHJhdGVneSUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NTc0MzE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      channel: 'Code Academy',
      progress: 45,
      whyChosen: 'Beginner friendly'
    },
    {
      id: '5',
      title: 'Digital Marketing Strategy',
      duration: '16:45',
      thumbnail: 'https://images.unsplash.com/photo-1709715357564-ab64e091ead9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJrZXRpbmclMjBzdHJhdGVneSUyMHByZXNlbnRhdGlvbnxlbnwxfHx8fDE3NTc0MzE2NjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      channel: 'Growth Experts',
      progress: 0,
      whyChosen: 'Industry expert'
    }
  ];

  const sortedLessons = [...mockPlaylistLessons].sort((a, b) => {
    switch(sortBy) {
      case 'recently-added':
        return 0; // Keep original order for recently added
      case 'in-progress':
        return (b.progress > 0 && b.progress < 100 ? 1 : 0) - (a.progress > 0 && a.progress < 100 ? 1 : 0);
      case 'completed':
        return (b.isCompleted ? 1 : 0) - (a.isCompleted ? 1 : 0);
      default:
        return 0;
    }
  });

  const handleLessonClick = (lesson: LessonData) => {
    onNavigate('lesson', lesson);
  };

  const continueWatchingLesson = mockPlaylistLessons.find(lesson => lesson.progress > 0 && lesson.progress < 100);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <h1 className="text-2xl text-[#212121]">My Playlist</h1>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <Card className="border-2 border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-[#4F46E5] mb-1">{mockPlaylistLessons.length}</div>
              <div className="text-sm text-gray-600">Total Saved</div>
            </CardContent>
          </Card>
          
          <Card className="border-2 border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-[#FF0000] mb-1">
                {mockPlaylistLessons.filter(l => l.progress > 0 && l.progress < 100).length}
              </div>
              <div className="text-sm text-gray-600">In Progress</div>
            </CardContent>
          </Card>
          
          <Card className="border-2 border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-[#22C55E] mb-1">
                {mockPlaylistLessons.filter(l => l.isCompleted).length}
              </div>
              <div className="text-sm text-gray-600">Completed</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Continue Learning CTA */}
      {continueWatchingLesson && (
        <Card className="border-2 border-[#4F46E5] bg-[#4F46E5]/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-[#212121]">Continue Learning</h3>
              <div className="text-sm text-gray-600">{continueWatchingLesson.progress}% complete</div>
            </div>
            
            <div className="flex items-center gap-3 mb-4">
              <div className="w-16 h-12 bg-gray-200 rounded overflow-hidden flex-shrink-0">
                <img 
                  src={continueWatchingLesson.thumbnail} 
                  alt={continueWatchingLesson.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-[#212121] truncate">{continueWatchingLesson.title}</h4>
                <p className="text-sm text-gray-600">{continueWatchingLesson.channel}</p>
              </div>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
              <div 
                className="bg-[#FF0000] h-2 rounded-full transition-all duration-300"
                style={{ width: `${continueWatchingLesson.progress}%` }}
              />
            </div>
            
            <Button 
              onClick={() => handleLessonClick(continueWatchingLesson)}
              className="w-full bg-[#4F46E5] hover:bg-[#4338CA] text-white"
            >
              <Play className="w-4 h-4 mr-2" />
              Continue Learning
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Filter/Sort */}
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-[#212121]">All Lessons</h3>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[160px] border-2 border-gray-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="recently-added">Recently Added</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Lessons List */}
      <div className="space-y-3">
        {sortedLessons.map((lesson) => (
          <VideoCard
            key={lesson.id}
            lesson={lesson}
            onClick={() => handleLessonClick(lesson)}
            showProgress={true}
          />
        ))}
      </div>

      {/* Empty State (if no lessons) */}
      {mockPlaylistLessons.length === 0 && (
        <Card className="border-2 border-gray-200">
          <CardContent className="p-8 text-center">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="font-medium text-[#212121] mb-2">No saved lessons yet</h3>
            <p className="text-gray-600 mb-4">
              Start learning and save lessons to build your personal playlist
            </p>
            <Button 
              onClick={() => onNavigate('home')}
              className="bg-[#4F46E5] hover:bg-[#4338CA] text-white"
            >
              Explore Lessons
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}