import React from 'react';

// Confetti animation for quiz success
export const triggerConfetti = () => {
  const container = document.getElementById('confetti-container');
  if (!container) return;

  const colors = ['#22C55E', '#FACC15', '#3B82F6', '#4F46E5'];
  const confettiCount = 50;

  for (let i = 0; i < confettiCount; i++) {
    const confetti = document.createElement('div');
    confetti.className = 'absolute w-2 h-2 rounded animate-bounce';
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    confetti.style.left = Math.random() * 100 + '%';
    confetti.style.top = '-10px';
    confetti.style.animationDuration = (Math.random() * 3 + 2) + 's';
    confetti.style.animationDelay = Math.random() * 0.5 + 's';
    
    container.appendChild(confetti);
    
    // Animate falling
    setTimeout(() => {
      confetti.style.transform = `translateY(${window.innerHeight + 20}px) rotate(${Math.random() * 360}deg)`;
      confetti.style.transition = 'transform 3s ease-out';
    }, 10);
    
    // Clean up
    setTimeout(() => {
      if (confetti.parentNode) {
        confetti.parentNode.removeChild(confetti);
      }
    }, 3500);
  }
};

// Shake animation for wrong answers
export const triggerShake = (elementId: string) => {
  const element = document.getElementById(elementId);
  if (!element) return;
  
  element.classList.add('animate-pulse');
  element.style.animation = 'shake 0.5s ease-in-out';
  
  setTimeout(() => {
    element.classList.remove('animate-pulse');
    element.style.animation = '';
  }, 500);
};

// Wiggle animation for streak flame
export const WiggleFlame = ({ isActive = false }: { isActive?: boolean }) => (
  <span className={`inline-block ${isActive ? 'animate-bounce' : ''}`}>
    🔥
  </span>
);

// Pulsing AI badge
export const PulsingBadge = ({ children, className = '' }: { children: React.ReactNode; className?: string }) => (
  <span className={`inline-block animate-pulse ${className}`}>
    {children}
  </span>
);

// CSS keyframes for shake animation (to be added via style tag)
export const addShakeAnimation = () => {
  if (document.getElementById('shake-animation')) return;
  
  const style = document.createElement('style');
  style.id = 'shake-animation';
  style.textContent = `
    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      10%, 30%, 50%, 70%, 90% { transform: translateX(-2px); }
      20%, 40%, 60%, 80% { transform: translateX(2px); }
    }
  `;
  document.head.appendChild(style);
};

// Initialize animations
export const initAnimations = () => {
  addShakeAnimation();
};