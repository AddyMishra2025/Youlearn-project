import React from 'react';
import { Play, FileText, Users, Download, ExternalLink, CheckCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import type { Screen } from '../App';

interface ResourcesScreenProps {
  onNavigate: (screen: Screen, data?: any) => void;
}

interface ResourceItem {
  id: string;
  type: 'video' | 'reading' | 'community' | 'tool';
  title: string;
  description: string;
  icon: React.ReactNode;
  recommended: boolean;
  completed?: boolean;
  url?: string;
}

export function ResourcesScreen({ onNavigate }: ResourcesScreenProps) {
  const resources: ResourceItem[] = [
    {
      id: '1',
      type: 'video',
      title: 'Welcome & Course Overview',
      description: 'Get oriented with the learning path structure and set expectations',
      icon: <Play className="w-6 h-6 text-[#FF0000]" />,
      recommended: true,
      completed: false
    },
    {
      id: '2',
      type: 'reading',
      title: 'Essential Reading Guide',
      description: 'Key articles and documentation to supplement your learning',
      icon: <FileText className="w-6 h-6 text-[#4F46E5]" />,
      recommended: true,
      completed: false,
      url: '#'
    },
    {
      id: '3',
      type: 'community',
      title: 'Join the Community Forum',
      description: 'Connect with fellow learners, ask questions, and share progress',
      icon: <Users className="w-6 h-6 text-[#22C55E]" />,
      recommended: true,
      completed: false,
      url: '#'
    },
    {
      id: '4',
      type: 'tool',
      title: 'Required Tools Setup',
      description: 'Download and install essential software (Excel, VS Code, etc.)',
      icon: <Download className="w-6 h-6 text-[#FF0000]" />,
      recommended: true,
      completed: false
    }
  ];

  const [completedResources, setCompletedResources] = React.useState<string[]>([]);

  const handleResourceClick = (resource: ResourceItem) => {
    if (resource.type === 'video') {
      // Navigate to a mock lesson
      const mockLesson = {
        id: resource.id,
        title: resource.title,
        duration: '8:30',
        thumbnail: 'https://images.unsplash.com/photo-1694878982098-1cec80d96eca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2RpbmclMjB0dXRvcmlhbCUyMHZpZGVvJTIwdGh1bWJuYWlsfGVufDF8fHx8MTc1NzQzMTY1NHww&ixlib=rb-4.1.0&q=80&w=1080',
        channel: 'YouLearn AI',
        progress: 0,
        whyChosen: 'Introduction video'
      };
      onNavigate('lesson', mockLesson);
    } else {
      // Mark as completed for other types
      setCompletedResources(prev => 
        prev.includes(resource.id) 
          ? prev.filter(id => id !== resource.id)
          : [...prev, resource.id]
      );
    }
  };

  const getTypeColor = (type: string) => {
    switch(type) {
      case 'video': return 'bg-[#FF0000]/10 text-[#FF0000] border-[#FF0000]/20';
      case 'reading': return 'bg-[#4F46E5]/10 text-[#4F46E5] border-[#4F46E5]/20';
      case 'community': return 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/20';
      case 'tool': return 'bg-orange-100 text-orange-600 border-orange-200';
      default: return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  const getTypeLabel = (type: string) => {
    switch(type) {
      case 'video': return 'Video';
      case 'reading': return 'Reading';
      case 'community': return 'Community';
      case 'tool': return 'Setup';
      default: return 'Resource';
    }
  };

  const completedCount = completedResources.length;
  const totalCount = resources.length;
  const progressPercentage = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4">
        <h1 className="text-2xl text-[#212121]">Get Started Resources</h1>
        <p className="text-gray-600">
          Essential resources to prepare you for successful learning
        </p>
        
        {/* Progress */}
        <Card className="border-2 border-[#4F46E5] bg-[#4F46E5]/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-medium text-[#212121]">Preparation Progress</h3>
              <span className="text-sm font-medium text-[#212121]">{completedCount}/{totalCount}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
              <div 
                className="bg-[#4F46E5] h-3 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <p className="text-sm text-gray-600">
              Complete these resources to be fully prepared for your learning journey
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Resources List */}
      <div className="space-y-4">
        {resources.map((resource) => {
          const isCompleted = completedResources.includes(resource.id);
          
          return (
            <Card 
              key={resource.id}
              className={`cursor-pointer transition-all duration-200 border-2 ${
                isCompleted 
                  ? 'border-[#22C55E] bg-[#22C55E]/5' 
                  : 'border-gray-200 hover:border-[#4F46E5] hover:shadow-md'
              }`}
              onClick={() => handleResourceClick(resource)}
            >
              <CardContent className="p-0">
                <div className="flex items-start gap-4 p-4">
                  {/* Icon */}
                  <div className={`p-3 rounded-lg ${
                    isCompleted ? 'bg-[#22C55E]/10' : 'bg-gray-50'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle className="w-6 h-6 text-[#22C55E]" />
                    ) : (
                      resource.icon
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className={`font-medium ${
                        isCompleted ? 'text-[#22C55E] line-through' : 'text-[#212121]'
                      }`}>
                        {resource.title}
                      </h3>
                      
                      <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                        <Badge className={getTypeColor(resource.type)}>
                          {getTypeLabel(resource.type)}
                        </Badge>
                        {resource.recommended && (
                          <Badge className="bg-[#4F46E5] text-white">
                            Recommended by AI
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <p className={`text-sm mb-3 ${
                      isCompleted ? 'text-gray-500' : 'text-gray-600'
                    }`}>
                      {resource.description}
                    </p>

                    {/* Action Button */}
                    {!isCompleted && (
                      <div className="flex items-center gap-2">
                        {resource.type === 'video' && (
                          <Button 
                            size="sm"
                            className="bg-[#FF0000] hover:bg-[#CC0000] text-white"
                          >
                            <Play className="w-4 h-4 mr-1" />
                            Watch Now
                          </Button>
                        )}
                        
                        {resource.type === 'reading' && (
                          <Button 
                            size="sm"
                            variant="outline"
                            className="border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white"
                          >
                            <FileText className="w-4 h-4 mr-1" />
                            Read Guide
                            <ExternalLink className="w-3 h-3 ml-1" />
                          </Button>
                        )}
                        
                        {resource.type === 'community' && (
                          <Button 
                            size="sm"
                            variant="outline"
                            className="border-[#22C55E] text-[#22C55E] hover:bg-[#22C55E] hover:text-white"
                          >
                            <Users className="w-4 h-4 mr-1" />
                            Join Community
                            <ExternalLink className="w-3 h-3 ml-1" />
                          </Button>
                        )}
                        
                        {resource.type === 'tool' && (
                          <Button 
                            size="sm"
                            variant="outline"
                            className="border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white"
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Setup Guide
                          </Button>
                        )}
                      </div>
                    )}

                    {isCompleted && (
                      <div className="flex items-center gap-2 text-sm text-[#22C55E]">
                        <CheckCircle className="w-4 h-4" />
                        <span>Completed</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Tips Card */}
      <Card className="border-2 border-yellow-200 bg-yellow-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="text-2xl">💡</div>
            <div>
              <h4 className="font-medium text-[#212121] mb-2">Pro Tip</h4>
              <p className="text-sm text-gray-700">
                Complete these resources in order for the best learning experience. Don't worry if you don't understand everything at first - that's normal!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Start Learning CTA */}
      <div className="sticky bottom-0 bg-[#F9F9F9] p-4 -mx-6 -mb-6 border-t border-gray-200">
        <Button 
          onClick={() => onNavigate('home')}
          className={`w-full p-4 rounded-lg text-base font-medium ${
            progressPercentage === 100
              ? 'bg-[#22C55E] hover:bg-[#16A34A] text-white'
              : 'bg-[#4F46E5] hover:bg-[#4338CA] text-white'
          }`}
        >
          {progressPercentage === 100 ? (
            <>
              <CheckCircle className="w-5 h-5 mr-2" />
              Start Learning Path →
            </>
          ) : (
            <>
              Continue Preparation ({completedCount}/{totalCount})
            </>
          )}
        </Button>
      </div>
    </div>
  );
}