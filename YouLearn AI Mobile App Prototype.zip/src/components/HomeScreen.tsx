import React, { useState, useEffect } from 'react';
import { Search, Sparkles, TrendingUp, BookOpen, Brain, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { initAnimations } from './AnimationHelpers';
import type { Screen, PathData } from '../App';

interface HomeScreenProps {
  onNavigate: (screen: Screen, data?: any) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    initAnimations();
  }, []);

  const topicChips = [
    { label: 'Excel Basics', icon: '📊', color: 'bg-[#22C55E]/10 text-[#22C55E] border-[#22C55E]/20' },
    { label: 'AI Tools', icon: '🤖', color: 'bg-[#4F46E5]/10 text-[#4F46E5] border-[#4F46E5]/20' },
    { label: 'Marketing Basics', icon: '📈', color: 'bg-[#3B82F6]/10 text-[#3B82F6] border-[#3B82F6]/20' },
  ];

  const handleGeneratePath = () => {
    if (!searchQuery.trim()) return;
    
    setIsLoading(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setIsLoading(false);
      
      // Mock path data based on search query
      const mockPath: PathData = {
        id: '1',
        title: searchQuery.includes('SQL') ? 'SQL Mastery Path' : 
               searchQuery.includes('Excel') ? 'Excel Professional Path' :
               searchQuery.includes('AI') ? 'AI Tools Mastery' : 'Custom Learning Path',
        totalLessons: 24,
        modules: [
          {
            title: 'Beginner Fundamentals',
            level: 'Beginner',
            estimatedTime: '~3 hrs total',
            lessons: [
              {
                id: '1',
                title: 'Getting Started with the Basics',
                duration: '12:45',
                thumbnail: 'https://images.unsplash.com/photo-1694878982098-1cec80d96eca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2RpbmclMjB0dXRvcmlhbCUyMHZpZGVvJTIwdGh1bWJuYWlsfGVufDF8fHx8MTc1NzQzMTY1NHww&ixlib=rb-4.1.0&q=80&w=1080',
                channel: 'TechEdu Pro',
                progress: 0,
                whyChosen: 'High rating, trusted source'
              },
              {
                id: '2',
                title: 'Core Concepts Explained',
                duration: '18:30',
                thumbnail: 'https://images.unsplash.com/photo-1606327054581-899eb5e6d1dc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNlbCUyMHNwcmVhZHNoZWV0JTIwdHV0b3JpYWx8ZW58MXx8fHwxNzU3NDMxNjU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
                channel: 'Learn Academy',
                progress: 0,
                whyChosen: 'Perfect for beginners'
              }
            ]
          },
          {
            title: 'Intermediate Skills',
            level: 'Intermediate',
            estimatedTime: '~5 hrs total',
            lessons: [
              {
                id: '3',
                title: 'Advanced Techniques & Tips',
                duration: '25:15',
                thumbnail: 'https://images.unsplash.com/photo-1564707944519-7a116ef3841c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxBSSUyMGFydGlmaWNpYWwlMjBpbnRlbGxpZ2VuY2UlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1NzM4NjUzN3ww&ixlib=rb-4.1.0&q=80&w=1080',
                channel: 'Pro Skills Hub',
                progress: 0,
                whyChosen: 'Industry expert instructor'
              }
            ]
          }
        ]
      };
      
      onNavigate('path', mockPath);
    }, 2000);
  };

  const handleTopicClick = (topic: string) => {
    setSearchQuery(`${topic} fundamentals in 2 weeks with short videos`);
  };

  if (isLoading) {
    return (
      <div className="p-6 min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#4F46E5]/5 to-[#3B82F6]/5">
        <div className="relative mb-6">
          <div className="w-16 h-16 border-4 border-[#4F46E5] border-t-transparent rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Zap className="w-6 h-6 text-[#4F46E5] animate-pulse" />
          </div>
        </div>
        <h2 className="text-xl mb-2 font-medium">AI is curating your path...</h2>
        <p className="text-gray-600 text-center max-w-sm">Finding the best lessons and creating your personalized learning journey ✨</p>
        <div className="flex items-center gap-2 mt-4 animate-pulse">
          <div className="w-2 h-2 bg-[#4F46E5] rounded-full animate-bounce"></div>
          <div className="w-2 h-2 bg-[#3B82F6] rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
          <div className="w-2 h-2 bg-[#22C55E] rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-[#4F46E5]/5 via-transparent to-[#3B82F6]/5 min-h-screen">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="relative">
            <Brain className="w-10 h-10 text-[#4F46E5] animate-pulse" />
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#FACC15] rounded-full animate-bounce"></div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#4F46E5] to-[#3B82F6] bg-clip-text text-transparent">
            YouLearn AI
          </h1>
        </div>
        <h2 className="text-xl text-[#212121] mb-6 font-medium">What do you want to learn? ✨</h2>
      </div>

      {/* Search Input */}
      <div className="space-y-4">
        <div className="relative">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="e.g. SQL basics in 2 weeks with short videos"
            className="w-full p-4 pr-12 text-base rounded-lg border-2 border-gray-200 focus:border-[#4F46E5] focus:ring-2 focus:ring-[#4F46E5]/20"
          />
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>
        
        <Button
          onClick={handleGeneratePath}
          disabled={!searchQuery.trim()}
          className="w-full bg-gradient-to-r from-[#4F46E5] to-[#3B82F6] hover:from-[#4338CA] hover:to-[#2563EB] text-white p-4 rounded-xl text-base font-medium transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          <Sparkles className="w-5 h-5 mr-2 animate-pulse" />
          Generate My Path
        </Button>
      </div>

      {/* Topic Chips */}
      <div className="space-y-3">
        <h3 className="text-lg text-[#212121] mb-3">Popular Topics</h3>
        <div className="grid grid-cols-3 gap-3">
          {topicChips.map((topic, index) => (
            <Button
              key={index}
              variant="outline"
              onClick={() => handleTopicClick(topic.label)}
              className={`p-4 h-auto flex flex-col items-center gap-2 border-2 ${topic.color} rounded-xl transform hover:scale-105 transition-all duration-200 hover:shadow-md`}
            >
              <span className="text-2xl animate-bounce" style={{animationDelay: `${index * 0.1}s`}}>{topic.icon}</span>
              <span className="text-xs font-medium">{topic.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Quick Access */}
      <div className="space-y-3">
        <h3 className="text-lg text-[#212121] mb-3">Quick Access</h3>
        <div className="grid gap-3">
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2 border-[#4F46E5]/20 hover:border-[#4F46E5] hover:bg-[#4F46E5]/5 rounded-xl transform hover:scale-105"
            onClick={() => onNavigate('playlist')}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 bg-[#4F46E5]/10 rounded-lg">
                <BookOpen className="w-5 h-5 text-[#4F46E5]" />
              </div>
              <div>
                <h4 className="font-medium text-[#212121]">My Playlist</h4>
                <p className="text-sm text-gray-600">Continue your saved lessons</p>
              </div>
            </CardContent>
          </Card>
          
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all duration-200 border-2 border-[#FF0000]/20 hover:border-[#FF0000] hover:bg-[#FF0000]/5 rounded-xl transform hover:scale-105"
            onClick={() => onNavigate('trending')}
          >
            <CardContent className="p-4 flex items-center gap-3">
              <div className="p-2 bg-[#FF0000]/10 rounded-lg">
                <TrendingUp className="w-5 h-5 text-[#FF0000] animate-pulse" />
              </div>
              <div>
                <h4 className="font-medium text-[#212121]">Trending Now 🔥</h4>
                <p className="text-sm text-gray-600">Popular learning paths</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}