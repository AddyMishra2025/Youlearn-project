import React, { useState } from 'react';
import { Brain, Copy, Download, FileText, Lightbulb, AlertTriangle, Calculator } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import type { Screen, LessonData } from '../App';

interface NotesScreenProps {
  lesson: LessonData | null;
  onNavigate: (screen: Screen, data?: any) => void;
}

export function NotesScreen({ lesson, onNavigate }: NotesScreenProps) {
  // Safety check - redirect to home if no lesson data
  if (!lesson) {
    onNavigate('home');
    return null;
  }

  const [notes, setNotes] = useState(`Key concepts from "${lesson.title}":

• Introduction to fundamental principles
• Understanding the core workflow
• Common mistakes to avoid
• Best practices for implementation

Questions to research:
- How does this apply to real-world scenarios?
- What are the advanced techniques?

Practice exercises:
1. Try the basic example shown in the video
2. Create a simple project using these concepts`);

  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleAISummarize = () => {
    setIsGenerating(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setAiSummary(`# ${lesson.title} - Study Cheat Sheet

## 🎯 Key Concepts
- **Foundation Building**: Start with basics before advancing
- **Practical Application**: Apply concepts to real projects
- **Consistent Practice**: Regular engagement improves retention

## 📝 Essential Formulas & Methods
\`\`\`
// Basic implementation pattern
function basicExample() {
  // Step 1: Initialize
  // Step 2: Process
  // Step 3: Output
}
\`\`\`

## ⚠️ Common Pitfalls
- **Mistake #1**: Rushing through fundamentals
- **Mistake #2**: Not practicing enough
- **Mistake #3**: Ignoring error handling

## 🚀 Next Steps
1. Complete the practice exercises
2. Build a small project
3. Review advanced concepts
4. Join community discussions

## 💡 Pro Tips
- Use real-world examples to understand concepts
- Don't memorize - focus on understanding
- Ask questions when stuck`);
      
      setIsGenerating(false);
    }, 2000);
  };

  const handleCopy = () => {
    const textToCopy = aiSummary || notes;
    navigator.clipboard.writeText(textToCopy);
    // You could add a toast notification here
  };

  const handleExport = () => {
    const textToExport = aiSummary || notes;
    const blob = new Blob([textToExport], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${lesson.title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_notes.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-xl text-[#212121]">Study Notes</h1>
        <p className="text-sm text-gray-600">For: {lesson.title}</p>
      </div>

      {/* Notes Input */}
      <Card className="border-2 border-gray-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#212121]" />
              <h3 className="font-medium text-[#212121]">Your Notes</h3>
            </div>
            <Badge variant="outline" className="text-xs">
              Auto-saved
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Write your notes here..."
            className="min-h-[200px] text-base border-2 border-gray-200 focus:border-[#4F46E5] focus:ring-2 focus:ring-[#4F46E5]/20 font-mono"
          />
          
          <div className="flex gap-2 mt-4">
            <Button
              onClick={handleAISummarize}
              disabled={isGenerating || !notes.trim()}
              className="bg-[#4F46E5] hover:bg-[#4338CA] text-white"
            >
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Generating...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Summarize Notes with AI
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* AI-Generated Cheat Sheet */}
      {aiSummary && (
        <Card className="border-2 border-[#4F46E5] bg-[#4F46E5]/5">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-[#4F46E5]" />
                <h3 className="font-medium text-[#212121]">AI-Generated Cheat Sheet</h3>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopy}
                  className="border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white"
                >
                  <Copy className="w-4 h-4 mr-1" />
                  Copy
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleExport}
                  className="border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white"
                >
                  <Download className="w-4 h-4 mr-1" />
                  Export
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <div className="space-y-4 font-mono text-sm">
                {/* Parse and render the markdown-style content */}
                {aiSummary.split('\n').map((line, index) => {
                  if (line.startsWith('# ')) {
                    return <h1 key={index} className="text-lg font-bold text-[#212121] font-sans">{line.substring(2)}</h1>;
                  }
                  if (line.startsWith('## ')) {
                    const content = line.substring(3);
                    let icon = null;
                    if (content.includes('🎯')) icon = <Lightbulb className="w-4 h-4 text-[#4F46E5]" />;
                    if (content.includes('📝')) icon = <Calculator className="w-4 h-4 text-[#22C55E]" />;
                    if (content.includes('⚠️')) icon = <AlertTriangle className="w-4 h-4 text-[#EF4444]" />;
                    if (content.includes('🚀')) icon = <FileText className="w-4 h-4 text-[#4F46E5]" />;
                    if (content.includes('💡')) icon = <Brain className="w-4 h-4 text-[#FF0000]" />;
                    
                    return (
                      <div key={index} className="flex items-center gap-2 mt-4 mb-2">
                        {icon}
                        <h2 className="font-semibold text-[#212121] font-sans">{content}</h2>
                      </div>
                    );
                  }
                  if (line.startsWith('- ')) {
                    return (
                      <div key={index} className="flex items-start gap-2 ml-4">
                        <span className="w-2 h-2 bg-[#4F46E5] rounded-full mt-2 flex-shrink-0"></span>
                        <span className="text-gray-700">{line.substring(2)}</span>
                      </div>
                    );
                  }
                  if (line.match(/^\d+\./)) {
                    return (
                      <div key={index} className="flex items-start gap-2 ml-4">
                        <span className="text-[#4F46E5] font-semibold">{line.split('.')[0]}.</span>
                        <span className="text-gray-700">{line.substring(line.indexOf('.') + 1).trim()}</span>
                      </div>
                    );
                  }
                  if (line.startsWith('```')) {
                    return null; // Skip code block markers for now
                  }
                  if (line.trim() === '') {
                    return <div key={index} className="h-2"></div>;
                  }
                  return <p key={index} className="text-gray-700">{line}</p>;
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Study Tips */}
      <Card className="border-2 border-gray-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-[#FF0000] mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-medium text-[#212121] mb-2">Study Tip</h4>
              <p className="text-sm text-gray-700">
                Review your notes within 24 hours to improve retention. Try explaining the concepts to someone else or create simple examples.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="sticky bottom-0 bg-[#F9F9F9] p-4 -mx-6 -mb-6 border-t border-gray-200">
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => onNavigate('lesson', lesson)}
            className="flex-1 border-gray-300 text-[#212121] hover:bg-gray-100"
          >
            Back to Lesson
          </Button>
          
          <Button
            className="flex-1 bg-[#22C55E] hover:bg-[#16A34A] text-white"
            onClick={() => {}}
          >
            Mark as Complete
          </Button>
        </div>
      </div>
    </div>
  );
}