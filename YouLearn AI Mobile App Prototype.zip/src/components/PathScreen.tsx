import React, { useState } from 'react';
import { Clock, Users, ChevronDown, ChevronUp, Play, CheckCircle, Target, Briefcase, Zap, BookOpen } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { VideoCard } from './VideoCard';
import type { Screen, PathData, LessonData } from '../App';

interface PathScreenProps {
  path: PathData | null;
  onNavigate: (screen: Screen, data?: any) => void;
}

export function PathScreen({ path, onNavigate }: PathScreenProps) {
  const [expandedModules, setExpandedModules] = useState<string[]>(['Beginner Fundamentals']);
  const [pathType, setPathType] = useState<'short-term' | 'career'>('short-term');

  // Safety check - redirect to home if no path data
  if (!path) {
    onNavigate('home');
    return null;
  }

  const toggleModule = (moduleTitle: string) => {
    setExpandedModules(prev => 
      prev.includes(moduleTitle) 
        ? prev.filter(m => m !== moduleTitle)
        : [...prev, moduleTitle]
    );
  };

  const handleLessonClick = (lesson: LessonData) => {
    onNavigate('lesson', lesson);
  };

  const getModuleBadgeColor = (level: string) => {
    switch(level) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Advanced': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const totalProgress = 35; // Mock progress

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-[#4F46E5]/5 via-transparent to-[#22C55E]/5 min-h-screen">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-[#212121]">{path.title}</h1>
          <Badge className="bg-[#4F46E5] text-white">
            {path.totalLessons} lessons
          </Badge>
        </div>
        
        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">Overall Progress</span>
            <span className="text-sm font-medium text-[#212121]">{totalProgress}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-[#FF0000] h-2 rounded-full transition-all duration-300"
              style={{ width: `${totalProgress}%` }}
            />
          </div>
        </div>

        {/* Path Type Toggle */}
        <div className="flex bg-white/80 backdrop-blur-sm rounded-xl p-2 border-2 border-[#4F46E5]/10 shadow-sm">
          <Button
            variant={pathType === 'short-term' ? 'default' : 'ghost'}
            onClick={() => setPathType('short-term')}
            className={`flex-1 rounded-lg transition-all duration-200 ${
              pathType === 'short-term' 
                ? 'bg-gradient-to-r from-[#3B82F6] to-[#4F46E5] text-white shadow-md' 
                : 'text-[#212121] hover:bg-[#3B82F6]/10'
            }`}
          >
            <Zap className="w-4 h-4 mr-2" />
            Quick Learning
          </Button>
          <Button
            variant={pathType === 'career' ? 'default' : 'ghost'}
            onClick={() => setPathType('career')}
            className={`flex-1 rounded-lg transition-all duration-200 ${
              pathType === 'career' 
                ? 'bg-gradient-to-r from-[#22C55E] to-[#4F46E5] text-white shadow-md' 
                : 'text-[#212121] hover:bg-[#22C55E]/10'
            }`}
          >
            <Briefcase className="w-4 h-4 mr-2" />
            Career Path
          </Button>
        </div>
        
        {pathType === 'short-term' && (
          <div className="bg-gradient-to-r from-[#3B82F6]/10 to-[#4F46E5]/10 p-4 rounded-xl border-l-4 border-[#3B82F6] animate-pulse">
            <p className="text-sm text-gray-700">
              <strong className="text-[#3B82F6]">⚡ Quick Learning:</strong> 3-5 focused lessons per module, ~1 hour each. Perfect for rapid skill building! 🚀
            </p>
          </div>
        )}
        
        {pathType === 'career' && (
          <div className="bg-gradient-to-r from-[#22C55E]/10 to-[#4F46E5]/10 p-4 rounded-xl border-l-4 border-[#22C55E] animate-pulse">
            <p className="text-sm text-gray-700">
              <strong className="text-[#22C55E]">🎯 Career Path:</strong> Comprehensive modules with career projects and portfolio building. Estimated 6-12 weeks of growth! 📈
            </p>
          </div>
        )}
      </div>

      {/* Get Started Resources */}
      <Card className="border-2 border-[#FACC15] bg-gradient-to-r from-[#FACC15]/10 to-[#4F46E5]/5 rounded-xl shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#4F46E5] animate-pulse" />
              <h3 className="font-medium text-[#212121]">Ready to Start? ✨</h3>
            </div>
            <Badge className="bg-gradient-to-r from-[#FACC15] to-[#4F46E5] text-white animate-pulse">
              AI Recommended
            </Badge>
          </div>
          <p className="text-sm text-gray-600 mb-3">
            Get essential resources before beginning your learning journey 🚀
          </p>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => onNavigate('resources')}
            className="border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white rounded-full transform hover:scale-105 transition-all duration-200"
          >
            View Resources ✨ →
          </Button>
        </CardContent>
      </Card>

      {/* Learning Modules */}
      <div className="space-y-4">
        {path.modules.map((module, index) => (
          <Card key={index} className="border-2 border-gray-200">
            <CardContent className="p-0">
              {/* Module Header */}
              <div 
                className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => toggleModule(module.title)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Badge className={getModuleBadgeColor(module.level)}>
                        {module.level}
                      </Badge>
                      {expandedModules.includes(module.title) ? 
                        <ChevronUp className="w-5 h-5 text-gray-500" /> : 
                        <ChevronDown className="w-5 h-5 text-gray-500" />
                      }
                    </div>
                    <div>
                      <h3 className="font-medium text-[#212121]">{module.title}</h3>
                      <div className="flex items-center gap-4 mt-1">
                        <span className="text-sm text-gray-600 flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {module.estimatedTime}
                        </span>
                        <span className="text-sm text-gray-600 flex items-center gap-1">
                          <Play className="w-4 h-4" />
                          {module.lessons.length} lessons
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Module Content */}
              {expandedModules.includes(module.title) && (
                <div className="border-t border-gray-200 bg-gray-50/50">
                  <div className="p-4 space-y-3">
                    {module.lessons.map((lesson, lessonIndex) => (
                      <VideoCard
                        key={lesson.id}
                        lesson={lesson}
                        onClick={() => handleLessonClick(lesson)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Continue Learning Button */}
      <div className="sticky bottom-0 bg-gradient-to-t from-[#FAFAFA] to-transparent p-4 -mx-6 -mb-6 backdrop-blur-sm">
        <Button 
          className="w-full bg-gradient-to-r from-[#4F46E5] to-[#22C55E] hover:from-[#4338CA] hover:to-[#16A34A] text-white p-4 rounded-xl text-base font-medium shadow-lg transform hover:scale-105 transition-all duration-200"
          onClick={() => handleLessonClick(path.modules[0].lessons[0])}
        >
          <Play className="w-5 h-5 mr-2 animate-pulse" />
          Continue Learning ✨
        </Button>
      </div>
    </div>
  );
}