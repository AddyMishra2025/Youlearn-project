import React from 'react';
import { Play, Clock, CheckCircle } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { LessonData } from '../App';

interface VideoCardProps {
  lesson: LessonData;
  onClick: () => void;
  showProgress?: boolean;
}

export function VideoCard({ lesson, onClick, showProgress = true }: VideoCardProps) {
  return (
    <Card 
      className="cursor-pointer hover:shadow-xl transition-all duration-300 border-2 border-white/50 hover:border-[#4F46E5] bg-white/80 backdrop-blur-sm rounded-xl transform hover:scale-105 hover:-translate-y-1"
      onClick={onClick}
    >
      <CardContent className="p-0">
        <div className="flex gap-3 p-3">
          {/* Thumbnail */}
          <div className="relative flex-shrink-0">
            <div className="w-32 h-20 bg-gray-200 rounded-lg overflow-hidden">
              <ImageWithFallback
                src={lesson.thumbnail}
                alt={lesson.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <div className="w-8 h-8 bg-[#FF0000] rounded-full flex items-center justify-center">
                  <Play className="w-4 h-4 text-white ml-0.5" fill="white" />
                </div>
              </div>
              <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                {lesson.duration}
              </div>
            </div>
            
            {/* Progress bar */}
            {showProgress && lesson.progress > 0 && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-300 rounded-b-lg">
                <div 
                  className="h-1 bg-[#FF0000] rounded-b-lg transition-all duration-300"
                  style={{ width: `${lesson.progress}%` }}
                />
              </div>
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="space-y-2">
              <h4 className="font-medium text-[#212121] line-clamp-2 leading-tight">
                {lesson.title}
              </h4>
              
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>{lesson.channel}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {lesson.duration}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {lesson.whyChosen && (
                  <Badge className="text-xs bg-[#4F46E5] text-white">
                    AI Pick: {lesson.whyChosen}
                  </Badge>
                )}
                
                {lesson.isCompleted && (
                  <Badge className="text-xs bg-[#22C55E] text-white">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Completed
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}