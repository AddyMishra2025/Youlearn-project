import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, Maximize, Subtitles, ChevronRight, BookOpen, Brain, CheckCircle, X, RotateCcw, Flame, Award, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { triggerConfetti, triggerShake, WiggleFlame, initAnimations } from './AnimationHelpers';
import type { Screen, LessonData } from '../App';

interface LessonScreenProps {
  lesson: LessonData | null;
  onNavigate: (screen: Screen, data?: any) => void;
}

export function LessonScreen({ lesson, onNavigate }: LessonScreenProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showSubtitles, setShowSubtitles] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState(85);
  const [streak, setStreak] = useState(7);

  useEffect(() => {
    initAnimations();
  }, []);

  // Safety check - redirect to home if no lesson data
  if (!lesson) {
    onNavigate('home');
    return null;
  }

  const mockQuizzes = [
    {
      question: "What is the primary benefit of using AI in learning?",
      options: [
        "Faster completion times",
        "Personalized content curation",
        "Lower costs",
        "Better graphics"
      ],
      correctAnswer: 1,
      explanation: "AI can analyze your learning patterns and curate content specifically tailored to your needs and pace."
    },
    {
      question: "Which feature helps with accessibility in video lessons?",
      options: [
        "High resolution",
        "Subtitles/Captions",
        "Faster playback",
        "Mobile optimization"
      ],
      correctAnswer: 1,
      explanation: "Subtitles and captions make content accessible to learners with hearing difficulties and help with comprehension."
    }
  ];

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return;
    
    const isCorrect = selectedAnswer === mockQuizzes[currentQuiz].correctAnswer;
    
    if (isCorrect) {
      setScore(prev => prev + 10);
      setStreak(prev => prev + 1);
      triggerConfetti();
    } else {
      triggerShake('quiz-container');
    }
    
    setQuizCompleted(true);
  };

  const handleNextQuestion = () => {
    if (currentQuiz < mockQuizzes.length - 1) {
      setCurrentQuiz(prev => prev + 1);
      setSelectedAnswer(null);
      setQuizCompleted(false);
    }
  };

  const handleRetryQuestion = () => {
    setSelectedAnswer(null);
    setQuizCompleted(false);
  };

  const isCorrectAnswer = selectedAnswer === mockQuizzes[currentQuiz].correctAnswer;

  return (
    <div className="bg-[#FAFAFA] min-h-screen">
      {/* Video Player */}
      <div className="bg-black relative">
        <div className="aspect-video relative">
          <ImageWithFallback
            src={lesson.thumbnail}
            alt={lesson.title}
            className="w-full h-full object-cover"
          />
          
          {/* Play/Pause Overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Button
              variant="ghost"
              size="lg"
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-16 h-16 bg-black/50 hover:bg-black/70 rounded-full"
            >
              {isPlaying ? 
                <Pause className="w-8 h-8 text-white" fill="white" /> : 
                <Play className="w-8 h-8 text-white ml-1" fill="white" />
              }
            </Button>
          </div>

          {/* Video Controls */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
            <div className="flex items-center justify-between text-white">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="hover:bg-white/20 p-2"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </Button>
                <Volume2 className="w-5 h-5" />
                <span className="text-sm">5:32 / {lesson.duration}</span>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowSubtitles(!showSubtitles)}
                  className={`hover:bg-white/20 p-2 ${showSubtitles ? 'bg-white/20' : ''}`}
                >
                  <Subtitles className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="hover:bg-white/20 p-2"
                >
                  <Maximize className="w-5 h-5" />
                </Button>
              </div>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-white/30 rounded-full h-1 mt-3">
              <div className="bg-[#FF0000] h-1 rounded-full w-[40%]" />
            </div>
          </div>

          {/* Subtitles */}
          {showSubtitles && (
            <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded text-center max-w-[80%]">
              Welcome to this comprehensive tutorial on getting started with the basics...
            </div>
          )}
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Video Info */}
        <div className="space-y-3">
          <h1 className="text-xl text-[#212121]">{lesson.title}</h1>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <span>{lesson.channel}</span>
            <span>•</span>
            <span>{lesson.duration}</span>
            <Badge className="bg-[#4F46E5] text-white">
              AI Pick: {lesson.whyChosen || 'Recommended for you'}
            </Badge>
          </div>
        </div>

        {/* Gamification Stats */}
        <Card className="border-2 border-[#FACC15] bg-gradient-to-r from-[#FACC15]/10 to-[#22C55E]/10 rounded-xl">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 bg-[#4F46E5]/10 px-3 py-1 rounded-full">
                  <Zap className="w-4 h-4 text-[#4F46E5] animate-pulse" />
                  <span className="font-bold text-[#4F46E5]">{score} XP</span>
                </div>
                <div className="flex items-center gap-2 bg-[#FACC15]/20 px-3 py-1 rounded-full">
                  <WiggleFlame isActive={streak > 5} />
                  <span className="font-bold text-[#212121]">{streak} day streak</span>
                </div>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                className="border-[#3B82F6] text-[#3B82F6] hover:bg-[#3B82F6] hover:text-white rounded-full transform hover:scale-105 transition-all duration-200"
              >
                🏆 Leaderboard
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* AI Summary */}
        <Card className="border-2 border-gray-200">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-[#4F46E5]" />
              <h3 className="font-medium text-[#212121]">AI Summary</h3>
            </div>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            <div className="bg-[#4F46E5]/5 p-4 rounded-lg border-l-4 border-[#4F46E5]">
              <p className="font-medium text-[#212121] mb-2">Key Takeaway:</p>
              <p className="text-gray-700">Understanding the fundamental concepts is crucial for building a strong foundation in any new skill.</p>
            </div>
            
            <div>
              <p className="font-medium text-[#212121] mb-2">Key Points:</p>
              <ul className="space-y-1 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-[#4F46E5] rounded-full mt-2 flex-shrink-0"></span>
                  Start with basic concepts before moving to advanced topics
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-[#4F46E5] rounded-full mt-2 flex-shrink-0"></span>
                  Practice regularly to reinforce learning
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-[#4F46E5] rounded-full mt-2 flex-shrink-0"></span>
                  Use real-world examples to understand practical applications
                </li>
              </ul>
            </div>

            <div className="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-400">
              <p className="font-medium text-[#212121] mb-2">Common Misconceptions:</p>
              <p className="text-gray-700">Many beginners think they need to memorize everything - focus on understanding concepts instead.</p>
            </div>

            <div className="bg-green-50 p-4 rounded-lg border-l-4 border-[#22C55E]">
              <p className="font-medium text-[#212121] mb-2">Practice Task:</p>
              <p className="text-gray-700">Try applying the concepts learned in this video to a simple project or exercise.</p>
            </div>
          </CardContent>
        </Card>

        {/* Interactive Quiz */}
        <Card id="quiz-container" className="border-2 border-[#3B82F6]/20 bg-gradient-to-br from-[#3B82F6]/5 to-transparent rounded-xl">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-[#3B82F6]/10 rounded-lg">
                  <Brain className="w-5 h-5 text-[#3B82F6]" />
                </div>
                <h3 className="font-medium text-[#212121]">Knowledge Check ✨</h3>
              </div>
              <Badge className="bg-[#3B82F6]/10 text-[#3B82F6] border-[#3B82F6]/20">
                {currentQuiz + 1} of {mockQuizzes.length}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            <h4 className="font-medium text-[#212121]">
              {mockQuizzes[currentQuiz].question}
            </h4>
            
            <div className="space-y-2">
              {mockQuizzes[currentQuiz].options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleAnswerSelect(index)}
                  disabled={quizCompleted}
                  className={`w-full text-left justify-start p-4 h-auto ${
                    selectedAnswer === index
                      ? quizCompleted
                        ? index === mockQuizzes[currentQuiz].correctAnswer
                          ? 'border-[#22C55E] bg-[#22C55E]/10 text-[#22C55E]'
                          : 'border-[#EF4444] bg-[#EF4444]/10 text-[#EF4444]'
                        : 'border-[#4F46E5] bg-[#4F46E5]/10'
                      : quizCompleted && index === mockQuizzes[currentQuiz].correctAnswer
                        ? 'border-[#22C55E] bg-[#22C55E]/10 text-[#22C55E]'
                        : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      selectedAnswer === index
                        ? quizCompleted
                          ? index === mockQuizzes[currentQuiz].correctAnswer
                            ? 'border-[#22C55E] bg-[#22C55E]'
                            : 'border-[#EF4444] bg-[#EF4444]'
                          : 'border-[#4F46E5] bg-[#4F46E5]'
                        : quizCompleted && index === mockQuizzes[currentQuiz].correctAnswer
                          ? 'border-[#22C55E] bg-[#22C55E]'
                          : 'border-gray-300'
                    }`}>
                      {((selectedAnswer === index && quizCompleted) || 
                        (quizCompleted && index === mockQuizzes[currentQuiz].correctAnswer)) && (
                        <CheckCircle className="w-4 h-4 text-white" />
                      )}
                      {selectedAnswer === index && quizCompleted && index !== mockQuizzes[currentQuiz].correctAnswer && (
                        <X className="w-4 h-4 text-white" />
                      )}
                    </div>
                    <span>{option}</span>
                  </div>
                </Button>
              ))}
            </div>

            {!quizCompleted ? (
              <Button
                onClick={handleSubmitAnswer}
                disabled={selectedAnswer === null}
                className="w-full bg-[#4F46E5] hover:bg-[#4338CA] text-white"
              >
                Submit Answer
              </Button>
            ) : (
              <div className="space-y-4">
                <div className={`p-4 rounded-xl border-2 ${
                  isCorrectAnswer 
                    ? 'bg-gradient-to-r from-[#22C55E]/10 to-[#FACC15]/10 border-[#22C55E]' 
                    : 'bg-gradient-to-r from-[#EF4444]/10 to-transparent border-[#EF4444]'
                }`}>
                  <p className={`font-bold mb-2 ${isCorrectAnswer ? 'text-[#22C55E]' : 'text-[#EF4444]'}`}>
                    {isCorrectAnswer ? '🎉 Awesome! +10 XP' : '🤔 Not quite right'}
                  </p>
                  <p className="text-gray-700">
                    {mockQuizzes[currentQuiz].explanation}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  {!isCorrectAnswer && (
                    <Button
                      variant="outline"
                      onClick={handleRetryQuestion}
                      className="flex-1 border-[#EF4444] text-[#EF4444] hover:bg-[#EF4444] hover:text-white"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Try Again
                    </Button>
                  )}
                  
                  {currentQuiz < mockQuizzes.length - 1 ? (
                    <Button
                      onClick={handleNextQuestion}
                      className="flex-1 bg-gradient-to-r from-[#4F46E5] to-[#3B82F6] hover:from-[#4338CA] hover:to-[#2563EB] text-white rounded-xl transform hover:scale-105 transition-all duration-200"
                    >
                      Next Question ✨
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  ) : (
                    <Button
                      onClick={() => {}}
                      className="flex-1 bg-[#22C55E] hover:bg-[#16A34A] text-white"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Quiz Complete!
                    </Button>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => onNavigate('notes', lesson)}
            className="flex-1 border-[#4F46E5] text-[#4F46E5] hover:bg-[#4F46E5] hover:text-white rounded-xl transform hover:scale-105 transition-all duration-200"
          >
            <BookOpen className="w-4 h-4 mr-2" />
            📝 Take Notes
          </Button>
          
          <Button
            className="flex-1 bg-gradient-to-r from-[#22C55E] to-[#4F46E5] hover:from-[#16A34A] hover:to-[#4338CA] text-white rounded-xl transform hover:scale-105 transition-all duration-200 shadow-lg"
            onClick={() => {}}
          >
            Next Lesson ✨
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}