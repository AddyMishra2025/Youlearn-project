import React, { useState } from 'react';
import { ArrowLeft, Search, Play, Clock, Users, BookOpen, Star, ChevronDown, ChevronUp, X, Check, Filter, Flame } from 'lucide-react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { Textarea } from './components/ui/textarea';
import { HomeScreen } from './components/HomeScreen';
import { PathScreen } from './components/PathScreen';
import { LessonScreen } from './components/LessonScreen';
import { NotesScreen } from './components/NotesScreen';
import { MyPlaylistScreen } from './components/MyPlaylistScreen';
import { TrendingScreen } from './components/TrendingScreen';
import { ResourcesScreen } from './components/ResourcesScreen';

export type Screen = 'home' | 'path' | 'lesson' | 'notes' | 'playlist' | 'trending' | 'resources';

export interface LessonData {
  id: string;
  title: string;
  duration: string;
  thumbnail: string;
  channel: string;
  progress: number;
  whyChosen?: string;
  isCompleted?: boolean;
}

export interface PathData {
  id: string;
  title: string;
  totalLessons: number;
  modules: {
    title: string;
    level: 'Beginner' | 'Intermediate' | 'Advanced';
    lessons: LessonData[];
    estimatedTime: string;
  }[];
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [currentPath, setCurrentPath] = useState<PathData | null>(null);
  const [currentLesson, setCurrentLesson] = useState<LessonData | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<string[]>(['Home']);

  const navigateToScreen = (screen: Screen, data?: any) => {
    setCurrentScreen(screen);
    
    switch(screen) {
      case 'home':
        setBreadcrumbs(['Home']);
        break;
      case 'path':
        setCurrentPath(data);
        setBreadcrumbs(['Home', data?.title || 'Learning Path']);
        break;
      case 'lesson':
        setCurrentLesson(data);
        setBreadcrumbs(['Home', currentPath?.title || 'Path', data?.title || 'Lesson']);
        break;
      case 'notes':
        setBreadcrumbs(['Home', currentPath?.title || 'Path', currentLesson?.title || 'Lesson', 'Notes']);
        break;
      case 'playlist':
        setBreadcrumbs(['Home', 'My Playlist']);
        break;
      case 'trending':
        setBreadcrumbs(['Home', 'Trending']);
        break;
      case 'resources':
        setBreadcrumbs(['Home', 'Resources']);
        break;
    }
  };

  const goBack = () => {
    if (currentScreen === 'notes') {
      navigateToScreen('lesson', currentLesson);
    } else if (currentScreen === 'lesson') {
      navigateToScreen('path', currentPath);
    } else if (currentScreen === 'path' || currentScreen === 'playlist' || currentScreen === 'trending' || currentScreen === 'resources') {
      navigateToScreen('home');
    }
  };

  const renderScreen = () => {
    switch(currentScreen) {
      case 'home':
        return <HomeScreen onNavigate={navigateToScreen} />;
      case 'path':
        if (!currentPath) {
          navigateToScreen('home');
          return <HomeScreen onNavigate={navigateToScreen} />;
        }
        return <PathScreen path={currentPath} onNavigate={navigateToScreen} />;
      case 'lesson':
        if (!currentLesson) {
          navigateToScreen('home');
          return <HomeScreen onNavigate={navigateToScreen} />;
        }
        return <LessonScreen lesson={currentLesson} onNavigate={navigateToScreen} />;
      case 'notes':
        if (!currentLesson) {
          navigateToScreen('home');
          return <HomeScreen onNavigate={navigateToScreen} />;
        }
        return <NotesScreen lesson={currentLesson} onNavigate={navigateToScreen} />;
      case 'playlist':
        return <MyPlaylistScreen onNavigate={navigateToScreen} />;
      case 'trending':
        return <TrendingScreen onNavigate={navigateToScreen} />;
      case 'resources':
        return <ResourcesScreen onNavigate={navigateToScreen} />;
      default:
        return <HomeScreen onNavigate={navigateToScreen} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-[#212121]">
      {/* Header with Navigation */}
      {currentScreen !== 'home' && (
        <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={goBack}
              className="p-2 hover:bg-gray-100"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-1 text-sm text-gray-600">
              {breadcrumbs.map((crumb, index) => (
                <React.Fragment key={index}>
                  {index > 0 && <span className="mx-1">›</span>}
                  <span className={index === breadcrumbs.length - 1 ? 'text-[#212121] font-medium' : ''}>
                    {crumb}
                  </span>
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="pb-safe">
        {renderScreen()}
      </div>
      
      {/* Confetti Animation Container */}
      <div id="confetti-container" className="fixed inset-0 pointer-events-none z-50"></div>
    </div>
  );
}