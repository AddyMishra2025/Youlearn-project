
  # YouLearn AI Mobile App Prototype

  This is a code bundle for YouLearn AI Mobile App Prototype. The original project is available at https://www.figma.com/design/Lh1ARsLAbcGmzN9CyJjYiI/YouLearn-AI-Mobile-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  